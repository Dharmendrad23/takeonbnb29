/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("unavailable_dates");
  collection.createRule = "@request.auth.id != ''";
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("unavailable_dates");
  collection.createRule = "propertyId.hostId = @request.auth.id";
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})